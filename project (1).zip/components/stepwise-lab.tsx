'use client'

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { StepwiseExplainer, type GuideStep } from "./stepwise-explainer";

import {
  Car,
  Compass,
  Eye,
  Footprints,
  Hand,
  Pause,
  Play,
  RotateCcw,
} from "lucide-react";

type MotionScenario = "walking" | "arm_swing" | "vehicle" | "stationary";
type GaitProfile = "steady" | "irregular" | "brisk";
type PresetId = "normal" | "fool" | "strict" | "custom";

interface PeakPoint {
  id: number;
  time: number;
  value: number;
  kind: "accepted" | "false_positive" | "rejected";
}


const SCENARIO_INFO: Record<
  MotionScenario,
  { title: string; subtitle: string; icon: React.ReactNode }
> = {
  walking: {
    title: "Walking",
    subtitle: "Rhythmic gait",
    icon: <Footprints className="h-4 w-4" />,
  },
  arm_swing: {
    title: "Arm Swing",
    subtitle: "Hand movement",
    icon: <Hand className="h-4 w-4" />,
  },
  vehicle: {
    title: "Vehicle",
    subtitle: "Road vibration",
    icon: <Car className="h-4 w-4" />,
  },
  stationary: {
    title: "Stationary",
    subtitle: "At rest",
    icon: <Compass className="h-4 w-4" />,
  },
};

function format4(n: number): string {
  return String(Math.max(0, Math.floor(n))).padStart(4, "0");
}

function formatSignedG(v: number): string {
  const sign = v >= 0 ? "+" : "";
  return `${sign}${v.toFixed(2)} g`;
}

export const StepwiseLab: React.FC = () => {
  // Controls matching the reference layout
  const [scenario, setScenario] = useState<MotionScenario>("walking");
  const [intensityPct, setIntensityPct] = useState<number>(62); // 10 - 100
  const [noisePct, setNoisePct] = useState<number>(12); // 0 - 80
  const [thresholdG, setThresholdG] = useState<number>(0.72); // 0.20 - 1.40
  const [intervalMs, setIntervalMs] = useState<number>(360); // 200 - 800
  const [gait, setGait] = useState<GaitProfile>("steady");
  const [activePreset, setActivePreset] = useState<PresetId>("custom");

  // Playback & learning modes
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [xrayActive, setXrayActive] = useState<boolean>(false);
  const [selectedGuideStep, setSelectedGuideStep] = useState<GuideStep | null>(null);

  // Telemetry & counters
  const [watchSteps, setWatchSteps] = useState<number>(28);
  const [realSteps, setRealSteps] = useState<number>(41);
  const [lastDiagnostic, setLastDiagnostic] = useState<{
    type: "accepted" | "false_positive" | "missed" | "calm";
    title: string;
    detail: string;
  }>({
    type: "missed",
    title: "MISSED STEP: BELOW THRESHOLD",
    detail: "Walking peak did not pass validation",
  });

  const [xyz, setXyz] = useState<{ x: number; y: number; z: number }>({
    x: -0.23,
    y: 0.93,
    z: 0.33,
  });
  const [currentMag, setCurrentMag] = useState<number>(0.72);
  const [pipelineStage, setPipelineStage] = useState<number>(2);
  const [wristTransform, setWristTransform] = useState<{
    swingDeg: number;
    liftPx: number;
    wristTiltDeg: number;
  }>({ swingDeg: -8, liftPx: 0, wristTiltDeg: -4 });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const draggingRef = useRef<boolean>(false);

  const simRef = useRef({
    t: 0,
    prevFiltered: 0.5,
    prevSlope: 0,
    lastValidPeakMs: -9999,
    lastRealStepMs: -9999,
    swingAngle: -8,
    swingVel: 0,
    liftOffset: 0,
    liftVel: 0,
    samples: [] as { t: number; val: number }[],
    peaks: [] as PeakPoint[],
    nextPeakId: 1,
  });

  const liveParams = useRef({
    scenario,
    intensityPct,
    noisePct,
    thresholdG,
    intervalMs,
    gait,
    isRunning,
  });

  useEffect(() => {
    liveParams.current = {
      scenario,
      intensityPct,
      noisePct,
      thresholdG,
      intervalMs,
      gait,
      isRunning,
    };
  }, [scenario, intensityPct, noisePct, thresholdG, intervalMs, gait, isRunning]);

  const applyPreset = (id: PresetId) => {
    setActivePreset(id);
    if (id === "normal") {
      setScenario("walking");
      setIntensityPct(68);
      setNoisePct(12);
      setThresholdG(0.65);
      setIntervalMs(360);
      setGait("steady");
    } else if (id === "fool") {
      setScenario("arm_swing");
      setIntensityPct(84);
      setNoisePct(15);
      setThresholdG(0.45);
      setIntervalMs(300);
      setGait("irregular");
    } else if (id === "strict") {
      setScenario("walking");
      setIntensityPct(62);
      setNoisePct(12);
      setThresholdG(0.98);
      setIntervalMs(380);
      setGait("steady");
    }
  };

  const handleReset = () => {
    setWatchSteps(0);
    setRealSteps(0);
    setLastDiagnostic({
      type: "calm",
      title: "SIMULATION RESET",
      detail: "Counters zeroed — ready for live testing",
    });
    simRef.current.samples = [];
    simRef.current.peaks = [];
    simRef.current.lastValidPeakMs = -9999;
    simRef.current.lastRealStepMs = -9999;
    simRef.current.prevFiltered = 0.25;
    simRef.current.prevSlope = 0;
  };

  const setThresholdFromClientY = (clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const norm = Math.max(0.1, Math.min(0.9, (clientY - rect.top) / rect.height));
    // Top = 1.40g, Bottom = 0.20g
    const val = 1.4 - ((norm - 0.1) / 0.8) * (1.4 - 0.2);
    setActivePreset("custom");
    setThresholdG(Number(val.toFixed(2)));
  };

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (draggingRef.current) {
        setThresholdFromClientY(e.clientY);
      }
    };
    const onUp = () => {
      draggingRef.current = false;
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, []);

  // Main 60fps simulation & waveform renderer
  useEffect(() => {
    let raf = 0;
    let prevNow = performance.now();
    let uiTimer = 0;

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - prevNow) / 1000);
      prevNow = now;

      const {
        scenario: sc,
        intensityPct: intPct,
        noisePct: nPct,
        thresholdG: th,
        intervalMs: coolMs,
        gait: gProf,
        isRunning: running,
      } = liveParams.current;

      const s = simRef.current;

      if (running) {
        s.t += dt;
        const elapsedMs = s.t * 1000;
        const ampScale = intPct / 65;
        const noiseScale = nPct / 100;

        const jitter =
          ((Math.random() + Math.random() + Math.random() - 1.5) / 1.5) * noiseScale * 1.1;

        const freqMult = gProf === "brisk" ? 1.28 : gProf === "irregular" ? 0.92 : 1.0;

        let ax = 0;
        let ay = 0.93;
        let az = 0;
        let targetSwing = 0;
        let targetLift = 0;

        if (sc === "walking") {
          const cadence = 2.05 * freqMult * Math.PI * 2;
          const irregMod =
            gProf === "irregular" ? 1 + 0.28 * Math.sin(s.t * 3.1) : 1.0;
          const phase = s.t * cadence * irregMod;
          const wave = Math.sin(phase);
          const pulse = Math.pow(Math.max(0, wave), 2.1) * 0.85 * ampScale;

          ay = 0.93 + pulse * 0.45 + jitter * 0.45;
          ax = -0.23 * ampScale + Math.sin(phase * 0.5) * 0.24 * ampScale + jitter * 0.45;
          az = 0.33 * ampScale + Math.cos(phase) * 0.28 * ampScale + jitter * 0.4;

          targetSwing = Math.sin(phase) * 22 * Math.min(1.4, ampScale);
          targetLift = -Math.abs(Math.sin(phase)) * 10 * Math.min(1.4, ampScale);

          if (elapsedMs - s.lastRealStepMs >= 480 / freqMult && wave > 0.75) {
            s.lastRealStepMs = elapsedMs;
            setRealSteps((r) => r + 1);
          }
        } else if (sc === "arm_swing") {
          const wA = Math.sin(s.t * 5.2 * freqMult);
          const wB = Math.cos(s.t * 2.7);
          const swingPeak = Math.max(0, wA * 0.72 + wB * 0.48) * 0.95 * ampScale;

          ax = wA * 0.65 * ampScale + jitter * 0.6;
          ay = 0.93 + swingPeak * 0.48 + jitter * 0.5;
          az = wB * 0.42 * ampScale + jitter * 0.5;

          targetSwing = wA * 34 * Math.min(1.5, ampScale) + wB * 12;
          targetLift = -swingPeak * 14;
        } else if (sc === "vehicle") {
          const vib =
            (Math.sin(s.t * 14.5) * 0.5 +
              Math.sin(s.t * 8.4) * 0.35 +
              Math.cos(s.t * 23.0) * 0.2) *
            0.52 *
            ampScale;

          ax = Math.cos(s.t * 12.1) * 0.22 * ampScale + jitter * 0.6;
          ay = 0.93 + Math.max(0, vib) * 0.42 + jitter * 0.65;
          az = Math.sin(s.t * 10.3) * 0.24 * ampScale + jitter * 0.6;

          targetSwing = Math.sin(s.t * 13) * 5 * ampScale;
          targetLift = -Math.abs(vib) * 6;
        } else {
          // stationary
          ax = jitter * 0.35;
          ay = 0.93 + jitter * 0.35;
          az = jitter * 0.35;
          targetSwing = jitter * 7;
          targetLift = 0;
        }

        // Composite dynamic magnitude
        const mag = Math.sqrt(ax * ax + ay * ay + az * az);
        const composite = Math.max(
          0.18,
          Math.abs(mag - 0.95) * 1.45 + Math.max(0, ay - 0.93) * 0.85 + Math.abs(jitter) * 0.35
        );

        // Low-pass filter (alpha = 0.18)
        const alpha = 0.18;
        const filtered = s.prevFiltered + alpha * (composite - s.prevFiltered);
        const slope = filtered - s.prevFiltered;

        // Detect peak
        if (s.prevSlope > 0 && slope <= 0 && s.prevFiltered > 0.2) {
          const peakVal = s.prevFiltered;
          const sinceLast = elapsedMs - s.lastValidPeakMs;

          if (peakVal >= th && sinceLast >= coolMs) {
            s.lastValidPeakMs = elapsedMs;
            setWatchSteps((w) => w + 1);
            setPipelineStage(4);

            if (sc === "walking") {
              s.peaks.push({ id: s.nextPeakId++, time: s.t, value: peakVal, kind: "accepted" });
              setLastDiagnostic({
                type: "accepted",
                title: "VALID STEP DETECTED",
                detail: `Peak ${peakVal.toFixed(2)}g crossed ${th.toFixed(2)}g threshold`,
              });
            } else {
              s.peaks.push({
                id: s.nextPeakId++,
                time: s.t,
                value: peakVal,
                kind: "false_positive",
              });
              setLastDiagnostic({
                type: "false_positive",
                title: "FALSE POSITIVE: ALGORITHM FOOLED",
                detail: `${SCENARIO_INFO[sc].title} produced a ${peakVal.toFixed(2)}g peak above threshold`,
              });
            }
          } else {
            s.peaks.push({ id: s.nextPeakId++, time: s.t, value: peakVal, kind: "rejected" });
            setPipelineStage(3);
            if (sc === "walking" && peakVal < th) {
              setLastDiagnostic({
                type: "missed",
                title: "MISSED STEP: BELOW THRESHOLD",
                detail: "Walking peak did not pass validation",
              });
            }
          }
        }

        s.prevFiltered = filtered;
        s.prevSlope = slope;

        s.samples.push({ t: s.t, val: filtered });
        const horizon = 8.0;
        s.samples = s.samples.filter((pt) => s.t - pt.t <= horizon);
        s.peaks = s.peaks.filter((pk) => s.t - pk.time <= horizon);

        // Spring physics for arm & wrist
        const k = 160;
        const d = 15;
        const fSwing = (targetSwing - s.swingAngle) * k - s.swingVel * d;
        s.swingVel += fSwing * dt;
        s.swingAngle += s.swingVel * dt;

        const fLift = (targetLift - s.liftOffset) * k - s.liftVel * d;
        s.liftVel += fLift * dt;
        s.liftOffset += s.liftVel * dt;

        uiTimer += dt;
        if (uiTimer >= 0.05) {
          uiTimer = 0;
          setXyz({
            x: Number(ax.toFixed(2)),
            y: Number(ay.toFixed(2)),
            z: Number(az.toFixed(2)),
          });
          setCurrentMag(Number(filtered.toFixed(2)));
          setWristTransform({
            swingDeg: Number(s.swingAngle.toFixed(1)),
            liftPx: Number(s.liftOffset.toFixed(1)),
            wristTiltDeg: Number((s.swingAngle * 0.28).toFixed(1)),
          });
        }
      }

      // Draw composite magnitude chart
      const canvas = canvasRef.current;
      if (canvas) {
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        if (
          canvas.width !== Math.round(rect.width * dpr) ||
          canvas.height !== Math.round(rect.height * dpr)
        ) {
          canvas.width = Math.round(rect.width * dpr);
          canvas.height = Math.round(rect.height * dpr);
        }
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.save();
          ctx.scale(dpr, dpr);
          const w = rect.width;
          const h = rect.height;
          ctx.clearRect(0, 0, w, h);

          const toY = (v: number) => {
            const c = Math.max(0.2, Math.min(1.4, v));
            const ratio = (c - 0.2) / (1.4 - 0.2);
            return h * 0.86 - ratio * (h * 0.72);
          };

          const horizon = 8.0;
          const toX = (ptTime: number) => {
            const age = s.t - ptTime;
            return w - (age / horizon) * w;
          };

          // Y-axis grid ticks (0.5, 1.0, 1.5)
          const ticks = [0.5, 1.0, 1.4];
          ctx.font = "10px ui-monospace, SFMono-Regular, Menlo, monospace";
          ticks.forEach((tv) => {
            const ty = toY(tv);
            ctx.strokeStyle = "rgba(148,163,184,0.12)";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(34, ty);
            ctx.lineTo(w, ty);
            ctx.stroke();

            ctx.fillStyle = "#64748B";
            ctx.fillText(tv.toFixed(1), 6, ty + 3);
          });

          // Threshold dashed amber line
          const thY = toY(th);
          ctx.save();
          ctx.setLineDash([5, 5]);
          ctx.strokeStyle = "#F59E0B";
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(34, thY);
          ctx.lineTo(w, thY);
          ctx.stroke();
          ctx.restore();

          ctx.fillStyle = "#FBBF24";
          ctx.font = "600 11px ui-monospace, SFMono-Regular, Menlo, monospace";
          ctx.fillText(`${th.toFixed(2)} g`, w - 52, Math.max(14, thY - 6));

          // Signal waveform
          if (s.samples.length > 1) {
            ctx.strokeStyle = "#FF785F";
            ctx.lineWidth = 2;
            ctx.beginPath();
            s.samples.forEach((pt, idx) => {
              const px = toX(pt.t);
              const py = toY(pt.val);
              if (idx === 0) ctx.moveTo(px, py);
              else ctx.lineTo(px, py);
            });
            ctx.stroke();
          }

          // Peaks
          s.peaks.forEach((pk) => {
            const px = toX(pk.time);
            const py = toY(pk.value);
            if (pk.kind === "accepted") {
              ctx.beginPath();
              ctx.arc(px, py, 4.5, 0, Math.PI * 2);
              ctx.fillStyle = "#FF4D2E";
              ctx.fill();
            } else if (pk.kind === "false_positive") {
              ctx.beginPath();
              ctx.arc(px, py, 5, 0, Math.PI * 2);
              ctx.fillStyle = "#F43F5E";
              ctx.fill();
            } else {
              ctx.beginPath();
              ctx.arc(px, py, 3.5, 0, Math.PI * 2);
              ctx.strokeStyle = "#94A3B8";
              ctx.lineWidth = 1.5;
              ctx.stroke();
            }
          });

          ctx.restore();
        }
      }

      raf = requestAnimationFrame(frame);
    };

    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, []);

  const ghostSteps = Math.max(0, watchSteps - realSteps);
  const accuracyPct =
    realSteps > 0
      ? Math.max(0, Math.min(100, Math.round((1 - Math.abs(watchSteps - realSteps) / realSteps) * 100)))
      : watchSteps === 0
        ? 100
        : 0;


  return (
    <div className="stepwise-shell min-h-screen bg-[#08080A] text-[#E2E8F0] selection:bg-[#FF4D2E]/30">
      <div className="mx-auto max-w-[1440px] px-4 sm:px-7 lg:px-10">
        <header className="editorial-header">
          <div className="header-brand">
            <a href="#top" className="wordmark" aria-label="STEPWISE home">STEP<span>—</span>WISE</a>
            <div className="study-label"><i /> SENSOR STUDY № 04 <span>/</span> IMU SIMULATION</div>
          </div>
          <div className="challenge-presets" role="group" aria-label="Quick challenge presets">
            <span className="challenge-label">QUICK CHALLENGE</span>
            <button type="button" aria-pressed={activePreset === "normal"} onClick={() => applyPreset("normal")} className={`preset-pill ${activePreset === "normal" ? "selected" : ""}`}>Normal Walk</button>
            <button type="button" aria-pressed={activePreset === "fool"} onClick={() => applyPreset("fool")} className={`preset-pill ${activePreset === "fool" ? "selected" : ""}`}>Fool the Watch</button>
            <button type="button" aria-pressed={activePreset === "strict"} onClick={() => applyPreset("strict")} className={`preset-pill ${activePreset === "strict" ? "selected" : ""}`}>Over-Strict Filter</button>
          </div>
          <div className="header-actions">
            <Link href="/how-it-works" className="deep-dive-link">How It Works <span>(Deep Dive)</span></Link>
            <button
              type="button"
              className={`header-xray ${xrayActive ? "active" : ""}`}
              role="switch"
              aria-checked={xrayActive}
              onClick={() => setXrayActive((value) => !value)}
            >
              <Eye className="h-3.5 w-3.5" /> SENSOR X-RAY <span className="switch-track"><i /></span>
            </button>
            <span className="live-badge"><span className="live-dot" /> LIVE SIM</span>
            <button type="button" onClick={() => setIsRunning((running) => !running)} aria-label={isRunning ? "Pause simulation" : "Resume simulation"} className="icon-button">
              {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <button type="button" onClick={handleReset} className="text-button"><RotateCcw className="h-3.5 w-3.5" /> Reset</button>
          </div>
        </header>
        <div className="header-rule" />

        <section id="top" className="editorial-hero">
          <div className="hero-meta"><span>AN EXPERIMENT IN PERCEPTION</span><span>01 <i>—</i> 04</span></div>
          <h1>Can you fool a<br /><em>smartwatch</em> into<br />thinking you’re walking?</h1>
          <div className="hero-foot">
            <p>A wrist is a small, convincing liar. Tune the motion.<br className="desktop-break" /> Watch the algorithm decide what counts as a step.</p>
          </div>
          <div className="team-credit" aria-label="Project team: DEV GUINS">
            <span className="team-name"><i /> DEV GUINS</span>
            <span className="team-member"><b>01</b> Omar Ibrahim Khamis</span>
            <span className="team-member"><b>02</b> Mohamed Wael Salman</span>
            <span className="team-member"><b>03</b> Malek Mahmoud</span>
          </div>
        </section>

      <StepwiseExplainer selectedStep={selectedGuideStep} onSelectStep={setSelectedGuideStep} />


      {/* 3-Column Lab Grid */}
      <main className="mx-auto grid max-w-[1440px] gap-4 p-4 lg:grid-cols-[310px_1fr_320px]">
        {/* COLUMN 01: THE WRIST & WATCH */}
        <section className={`guide-target flex flex-col gap-3 rounded-xl border border-slate-800/80 bg-[#111115] p-4 ${selectedGuideStep === "01" ? "guide-focus" : ""}`}>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-mono text-[10px] tracking-widest text-slate-500">
                01 / DEVICE STAGE
              </div>
              <h2 className="text-sm font-semibold text-white">The wrist &amp; watch</h2>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[10px] text-orange-400">
              <span className="h-1.5 w-1.5 rounded-full bg-orange-400" />
              <span>CONNECTED</span>
            </div>
          </div>

          {/* Arm & Smartwatch Viewport */}
          <div className="relative flex h-64 flex-col justify-between overflow-hidden rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3">
            <div className="flex items-center justify-between font-mono text-[10px] text-slate-500">
              <span>WRIST SENSOR</span>
              <span>IMU · 50 Hz</span>
            </div>

            <div className="flex flex-1 items-center justify-center">
              <svg
                viewBox="0 0 280 180"
                className="h-full w-full overflow-visible"
                style={{
                  transform: `translateY(${wristTransform.liftPx}px) rotate(${wristTransform.swingDeg}deg)`,
                  transformOrigin: "120px 105px",
                }}
              >
                {/* Upper/Forearm */}
                <path
                  d="M 10 92 Q 65 82 135 90 L 135 128 Q 65 136 10 124 Z"
                  fill="#E5A97C"
                  stroke="#C98A5E"
                  strokeWidth="1.5"
                />
                {/* Hand */}
                <path
                  d="M 135 91 Q 168 86 196 96 Q 204 108 194 122 Q 166 130 135 127 Z"
                  fill="#EAB085"
                  stroke="#C98A5E"
                  strokeWidth="1.5"
                />
                {/* Watch Strap */}
                <rect
                  x="104"
                  y="85"
                  width="32"
                  height="48"
                  rx="6"
                  fill="#1E293B"
                  stroke="#334155"
                  strokeWidth="1.5"
                />
                {/* Watch Body */}
                <g
                  transform={`translate(120, 109) rotate(${wristTransform.wristTiltDeg})`}
                >
                  <rect
                    x="-22"
                    y="-26"
                    width="44"
                    height="52"
                    rx="11"
                    fill={xrayActive ? "#0F172A" : "#090D16"}
                    stroke={xrayActive ? "#F59E0B" : "#475569"}
                    strokeWidth="2"
                  />
                  {/* Watch Screen Content */}
                  <text
                    x="0"
                    y="-9"
                    textAnchor="middle"
                    fill="#94A3B8"
                    fontSize="8"
                    fontFamily="monospace"
                  >
                    09:41
                  </text>
                  <text
                    x="0"
                    y="7"
                    textAnchor="middle"
                    fill="#FF4D2E"
                    fontSize="11"
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    {format4(watchSteps)}
                  </text>
                  <text
                    x="0"
                    y="18"
                    textAnchor="middle"
                    fill="#64748B"
                    fontSize="6.5"
                    fontFamily="monospace"
                  >
                    {scenario.toUpperCase()}
                  </text>

                  {/* X-Ray Force Vectors */}
                  {xrayActive && (
                    <g>
                      <line
                        x1="0"
                        y1="0"
                        x2={xyz.x * 24}
                        y2="0"
                        stroke="#38BDF8"
                        strokeWidth="2"
                      />
                      <line
                        x1="0"
                        y1="0"
                        x2="0"
                        y2={-(xyz.y - 0.93) * 28}
                        stroke="#F59E0B"
                        strokeWidth="2"
                      />
                      <circle cx="0" cy="0" r="3" fill="#F43F5E" />
                    </g>
                  )}
                </g>
              </svg>
            </div>

            <div className="flex items-center justify-between font-mono text-[10px] text-slate-500">
              <span>MOTION PROFILE</span>
              <span>GAIT OSCILLATION</span>
            </div>
          </div>

          {/* Detected vs Actual Steps */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3.5">
              <div className="font-mono text-[10px] tracking-wider text-slate-400">
                DETECTED STEPS
              </div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-orange-400">
                {format4(watchSteps)}
              </div>
              <div className="mt-1 text-[11px] text-slate-500">Watch counter</div>
            </div>

            <div className="rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3.5">
              <div className="font-mono text-[10px] tracking-wider text-slate-400">
                ACTUAL STEPS
              </div>
              <div className="mt-1.5 font-mono text-2xl font-bold tabular-nums text-white">
                {format4(realSteps)}
              </div>
              <div className="mt-1 text-[11px] text-slate-500">
                {accuracyPct}% accuracy · {ghostSteps} ghost
              </div>
            </div>
          </div>


        </section>

        {/* COLUMN 02: SIGNAL PROCESSING LAB */}
        <section className={`guide-target flex flex-col justify-between gap-4 rounded-xl border border-slate-800/80 bg-[#111115] p-4 ${selectedGuideStep === "02" || selectedGuideStep === "03" ? "guide-focus" : ""}`}>
          <div className="flex items-center justify-between">
            <div>
              <div className="font-mono text-[10px] tracking-widest text-slate-500">
                02 / SIGNAL PROCESSING LAB
              </div>
              <h2 className="text-sm font-semibold text-white">Live accelerometer</h2>
            </div>
            <span className="rounded border border-slate-800 bg-slate-900 px-2.5 py-1 font-mono text-[11px] text-slate-300">
              50 Hz
            </span>
          </div>

          {/* X / Y / Z Axis Mini Bars */}
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3">
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="text-sky-400">
                  X <span className="text-[10px] text-slate-500">LATERAL</span>
                </span>
                <span className="font-bold text-white">{formatSignedG(xyz.x)}</span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-sky-400 transition-all duration-75"
                  style={{ width: `${Math.min(100, Math.max(10, (xyz.x + 1) * 50))}%` }}
                />
              </div>
            </div>

            <div className="rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3">
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="text-orange-400">
                  Y <span className="text-[10px] text-slate-500">VERTICAL</span>
                </span>
                <span className="font-bold text-white">{formatSignedG(xyz.y)}</span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-orange-400 transition-all duration-75"
                  style={{ width: `${Math.min(100, Math.max(10, (xyz.y / 1.8) * 100))}%` }}
                />
              </div>
            </div>

            <div className="rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3">
              <div className="flex items-center justify-between font-mono text-xs">
                <span className="text-violet-400">
                  Z <span className="text-[10px] text-slate-500">FORWARD / BACK</span>
                </span>
                <span className="font-bold text-white">{formatSignedG(xyz.z)}</span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-violet-400 transition-all duration-75"
                  style={{ width: `${Math.min(100, Math.max(10, (xyz.z + 0.8) * 55))}%` }}
                />
              </div>
            </div>
          </div>

          {/* Composite Magnitude Chart */}
          <div className="rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-4">
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-semibold text-white">Composite magnitude</h3>
                <p className="text-[11px] text-slate-400">
                  Filtered acceleration · rolling 8 seconds (drag amber line to adjust threshold)
                </p>
              </div>
              <div className="flex items-center gap-3 font-mono text-[10px] text-slate-400">
                <span className="flex items-center gap-1">
                  <span className="h-0.5 w-3 bg-[#FF785F]" /> SIGNAL
                </span>
                <span className="flex items-center gap-1">
                  <span className="h-0.5 w-3 border-t border-dashed border-amber-400" />{" "}
                  THRESHOLD
                </span>
              </div>
            </div>

            <div className="h-52 w-full">
              <canvas
                ref={canvasRef}
                aria-label="Live accelerometer magnitude chart. Drag vertically to adjust the detection threshold."
                onPointerDown={(e) => {
                  draggingRef.current = true;
                  setThresholdFromClientY(e.clientY);
                }}
                className="h-full w-full cursor-ns-resize touch-none"
              />
            </div>

            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 font-mono text-[11px] text-slate-400">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-orange-400" /> Accepted
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-rose-500" /> False positive
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full border border-slate-400" /> Rejected peak
                </span>
              </div>
              <span className="text-[10px] text-slate-500">LOW-PASS α = 0.18</span>
            </div>
          </div>


        </section>

        {/* COLUMN 03: EXPERIMENT CONTROLS */}
        <section className={`guide-target flex flex-col justify-between gap-4 rounded-xl border border-slate-800/80 bg-[#111115] p-4 ${selectedGuideStep === "04" ? "guide-focus" : ""}`}>
          <div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-mono text-[10px] tracking-widest text-slate-500">
                  03 / EXPERIMENT CONTROLS
                </div>
                <h2 className="text-sm font-semibold text-white">Motion scenarios</h2>
              </div>

            </div>

            {/* 2x2 Scenario Buttons */}
            <div className="mt-3 grid grid-cols-2 gap-2.5">
              {(Object.keys(SCENARIO_INFO) as MotionScenario[]).map((key) => {
                const selected = scenario === key;
                return (
                  <button
                    key={key}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => {
                      setActivePreset("custom");
                      setScenario(key);
                    }}
                    className={`flex flex-col items-start gap-1 rounded-xl border p-3 text-left transition ${
                      selected
                        ? "border-orange-500/60 bg-orange-500/10 text-white"
                        : "border-slate-800 bg-[#0B0B0E] text-slate-300 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-2 text-xs font-semibold">
                      <span className={selected ? "text-orange-400" : "text-slate-400"}>
                        {SCENARIO_INFO[key].icon}
                      </span>
                      <span>{SCENARIO_INFO[key].title}</span>
                    </div>
                    <span className="text-[11px] text-slate-500">
                      {SCENARIO_INFO[key].subtitle}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Algorithm & Physics Sliders */}
          <div className="space-y-3.5 rounded-xl border border-slate-800/90 bg-[#0B0B0E] p-3.5">
            <div className="font-mono text-[10px] tracking-widest text-slate-400">
              ALGORITHM &amp; PHYSICS
            </div>

            <div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-200">Motion intensity</span>
                <span className="font-mono text-white">{intensityPct}%</span>
              </div>
              <div className="text-[10px] text-slate-500">Amplitude of wrist movement</div>
              <input
                type="range"
                aria-label="Motion intensity"
                min={10}
                max={100}
                value={intensityPct}
                onChange={(e) => {
                  setActivePreset("custom");
                  setIntensityPct(Number(e.target.value));
                }}
                className="mt-1.5 w-full accent-sky-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-200">Sensor noise</span>
                <span className="font-mono text-white">{noisePct}%</span>
              </div>
              <div className="text-[10px] text-slate-500">Gaussian jitter injected into signal</div>
              <input
                type="range"
                aria-label="Sensor noise"
                min={0}
                max={80}
                value={noisePct}
                onChange={(e) => {
                  setActivePreset("custom");
                  setNoisePct(Number(e.target.value));
                }}
                className="mt-1.5 w-full accent-sky-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-200">Detection threshold</span>
                <span className="font-mono text-amber-400">{thresholdG.toFixed(2)} g</span>
              </div>
              <div className="text-[10px] text-slate-500">Minimum peak height to trigger a step</div>
              <input
                type="range"
                aria-label="Detection threshold"
                min={0.2}
                max={1.4}
                step={0.02}
                value={thresholdG}
                onChange={(e) => {
                  setActivePreset("custom");
                  setThresholdG(Number(e.target.value));
                }}
                className="mt-1.5 w-full accent-amber-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-200">Detection interval</span>
                <span className="font-mono text-sky-400">{intervalMs} ms</span>
              </div>
              <div className="text-[10px] text-slate-500">Cooldown between accepted peaks</div>
              <input
                type="range"
                aria-label="Detection interval"
                min={200}
                max={800}
                step={20}
                value={intervalMs}
                onChange={(e) => {
                  setActivePreset("custom");
                  setIntervalMs(Number(e.target.value));
                }}
                className="mt-1.5 w-full accent-sky-400"
              />
            </div>

            <div className="flex items-center justify-between border-t border-slate-800/80 pt-2.5">
              <div>
                <div className="text-xs text-slate-200">Gait pattern</div>
                <div className="text-[10px] text-slate-500">Walking cadence profile</div>
              </div>
              <div className="flex rounded-lg border border-slate-800 bg-slate-900/90 p-0.5 text-[11px]">
                {(["steady", "irregular", "brisk"] as GaitProfile[]).map((g) => (
                  <button
                    key={g}
                    type="button"
                    aria-pressed={gait === g}
                    onClick={() => {
                      setActivePreset("custom");
                      setGait(g);
                    }}
                    className={`rounded-md px-2 py-1 capitalize transition ${
                      gait === g ? "bg-slate-700 text-white" : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          </div>


        </section>
      </main>

      </div>
    </div>
  );
};

export default StepwiseLab;
