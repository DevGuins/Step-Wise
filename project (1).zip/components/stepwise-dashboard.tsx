'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Activity, ArrowUpRight, AudioLines, Check, ChevronDown, Gauge, RotateCcw, ScanLine, Watch } from 'lucide-react'

type Scenario = 'Walking' | 'Arm Swing' | 'Vehicle' | 'Stationary'
type Preset = 'Normal Walk' | 'Fool Watch' | 'Strict Filter'

const scenarios: { name: Scenario; detail: string }[] = [
  { name: 'Walking', detail: 'Natural gait' },
  { name: 'Arm Swing', detail: 'No footfall' },
  { name: 'Vehicle', detail: 'Road vibration' },
  { name: 'Stationary', detail: 'At rest' },
]

const presets: Record<Preset, { threshold: number; intensity: number; noise: number; interval: number; scenario: Scenario }> = {
  'Normal Walk': { threshold: 0.72, intensity: 1.05, noise: 0.12, interval: 520, scenario: 'Walking' },
  'Fool Watch': { threshold: 0.38, intensity: 0.82, noise: 0.24, interval: 560, scenario: 'Arm Swing' },
  'Strict Filter': { threshold: 1.18, intensity: 1.05, noise: 0.12, interval: 520, scenario: 'Walking' },
}

function formatCount(value: number) {
  return value.toLocaleString('en-US', { minimumIntegerDigits: 4, useGrouping: false })
}

export function StepwiseDashboard() {
  const [scenario, setScenario] = useState<Scenario>('Walking')
  const [preset, setPreset] = useState<Preset>('Normal Walk')
  const [threshold, setThreshold] = useState(0.72)
  const [intensity, setIntensity] = useState(1.05)
  const [noise, setNoise] = useState(0.12)
  const [interval, setInterval] = useState(520)
  const [xray, setXray] = useState(false)
  const [realSteps, setRealSteps] = useState(0)
  const [watchSteps, setWatchSteps] = useState(0)
  const [signal, setSignal] = useState(0.12)
  const [axes, setAxes] = useState({ x: 0.04, y: 0.98, z: 0.02 })
  const [tick, setTick] = useState(0)
  const [history, setHistory] = useState<number[]>(() => Array.from({ length: 88 }, (_, i) => 0.1 + Math.sin(i * 0.18) * 0.035))
  const timeRef = useRef(0)
  const lastStepRef = useRef(0)

  useEffect(() => {
    let frame = 0
    let last = 0
    let elapsed = 0
    const animate = (now: number) => {
      if (!last) last = now
      const dt = Math.min((now - last) / 1000, 0.05)
      last = now
      elapsed += dt
      timeRef.current += dt
      const t = timeRef.current
      const swing = scenario === 'Walking' ? 0.76 : scenario === 'Arm Swing' ? 0.51 : scenario === 'Vehicle' ? 0.27 : 0.035
      const period = scenario === 'Vehicle' ? 0.31 : interval / 1000
      const phase = Math.sin((t * Math.PI * 2) / period)
      const jitter = (Math.sin(t * 21.7) * 0.55 + Math.cos(t * 37.1) * 0.45) * noise
      const peak = Math.pow(Math.max(0, phase), scenario === 'Vehicle' ? 5 : 3.2) * swing * intensity
      const magnitude = Math.max(0, 0.11 + peak + jitter)
      const x = Math.sin(t * 7.4) * swing * 0.5 + jitter * 0.7
      const y = 0.98 + Math.cos(t * 7.4) * swing * 0.22 + peak * 0.42
      const z = Math.sin(t * 5.2 + 1) * swing * 0.32 + jitter * 0.5
      setSignal(magnitude)
      setAxes({ x, y, z })
      setHistory((values) => [...values.slice(-87), magnitude])
      if (elapsed > 0.08) {
        elapsed = 0
        setTick((value) => value + 1)
      }
      const qualifies = magnitude >= threshold && t - lastStepRef.current >= interval / 1000
      if (qualifies) {
        lastStepRef.current = t
        setWatchSteps((value) => value + 1)
        if (scenario === 'Walking') setRealSteps((value) => value + 1)
      }
      frame = requestAnimationFrame(animate)
    }
    frame = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(frame)
  }, [scenario, threshold, intensity, noise, interval])

  const status = watchSteps > realSteps + 2 ? 'Fooled!' : watchSteps < realSteps - 2 ? 'Under-counting' : 'Accurate'
  const peakPoints = useMemo(() => history.map((value, index) => `${(index / (history.length - 1)) * 100},${72 - Math.min(value, 1.65) / 1.65 * 62}`).join(' '), [history])
  const applyPreset = (name: Preset) => {
    const settings = presets[name]
    setPreset(name)
    setThreshold(settings.threshold)
    setIntensity(settings.intensity)
    setNoise(settings.noise)
    setInterval(settings.interval)
    setScenario(settings.scenario)
  }
  const reset = () => {
    setRealSteps(0)
    setWatchSteps(0)
    lastStepRef.current = timeRef.current
  }
  const note = scenario === 'Arm Swing'
    ? threshold < 0.55 ? 'Low threshold lets arm swings register as phantom steps.' : 'Raise intensity or lower threshold to create a convincing phantom gait.'
    : scenario === 'Vehicle'
      ? threshold < 0.4 ? 'Road vibration is crossing the step detector.' : 'The filter is rejecting most high-frequency road vibration.'
      : scenario === 'Stationary'
        ? 'At rest, only noise can cross the motion threshold.'
        : threshold > 1.05 ? 'Strict filtering is dropping softer parts of your natural gait.' : 'Each rhythmic footfall clears the threshold and counts once.'

  return (
    <main className="stepwise-shell min-h-screen px-4 pb-10 pt-5 text-[#F4F4F0] sm:px-7 lg:px-10">
      <div className="mx-auto max-w-[1440px]">
        <header className="editorial-header">
          <a href="#top" className="wordmark" aria-label="STEPWISE home">STEP<span>—</span>WISE</a>
          <div className="study-label"><i /> SENSOR STUDY № 04 <span>/</span> IMU SIMULATION</div>
          <button className={`header-xray ${xray ? 'active' : ''}`} role="switch" aria-checked={xray} onClick={() => setXray((value) => !value)}><span className="switch-track"><i /></span> SENSOR X-RAY</button>
        </header>
        <div className="header-rule" />

        <section id="top" className="editorial-hero">
          <div className="hero-meta"><span>AN EXPERIMENT IN PERCEPTION</span><span>{String(scenarios.findIndex((item) => item.name === scenario) + 1).padStart(2, '0')} <i>—</i> 04</span></div>
          <h1>Can you fool a<br /><em>smartwatch</em> into<br />thinking you’re walking?</h1>
          <div className="hero-foot">
            <p>A wrist is a small, convincing liar. Tune the motion.<br className="desktop-break" /> Watch the algorithm decide what counts as a step.</p>
            <div className="hero-tools">
              <div className="hero-comparison">
                <div><small>REAL STEPS</small><b>{formatCount(realSteps)}</b></div><span className="comparison-divider" />
                <div><small>WATCH STEPS</small><b>{formatCount(watchSteps)}</b></div>
                <span className={`status-pill ${status === 'Fooled!' ? 'is-fooled' : status === 'Under-counting' ? 'is-under' : ''}`}>{status}</span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {(Object.keys(presets) as Preset[]).map((item) => <button key={item} className={`preset-pill ${preset === item ? 'selected' : ''}`} onClick={() => applyPreset(item)}>{preset === item && <Check size={12} />}{item}</button>)}
                <button className="text-button" onClick={reset}>Reset <RotateCcw size={12} /></button>
              </div>
            </div>
          </div>
        </section>

        <section className="main-grid mt-7">
          <article className="lens-panel surface overflow-hidden rounded-[30px] border border-white/[0.09]">
            <div className="panel-head flex items-center justify-between px-6 pt-5 sm:px-8">
              <div><div className="section-label">01 / THE WRIST</div><div className="mt-1 text-sm text-white/80">Observed movement</div></div>
              <div className="live-badge"><span className="live-dot" /> LIVE <span className="ml-1 font-mono text-[#8E8E98]">60 FPS</span></div>
            </div>
            <div className={`wrist-stage ${scenario === 'Stationary' ? 'still' : ''}`}>
              <div className={`lens-ring ${tick % 8 === 0 && signal > threshold ? 'pulse' : ''}`}>
                <div className="orbit orbit-a" /><div className="orbit orbit-b" />
                <div className="axis-label axis-x">X <span>{axes.x.toFixed(2)}</span></div><div className="axis-label axis-y">Y <span>{axes.y.toFixed(2)}</span></div><div className="axis-label axis-z">Z <span>{axes.z.toFixed(2)}</span></div>
                <div className="arm"><div className="arm-shadow" /><div className="watch-strap strap-top" /><div className="watch-body"><div className="watch-glass"><div className="watch-time">09:41</div><div className="watch-date">TUE, MAY 21</div><div className="watch-steps"><Activity size={11} color="#FF4D2E" /> {formatCount(watchSteps)}</div><div className="watch-caption">STEPS</div><div className="watch-progress"><i /></div>{xray && <div className="watch-axes"><span>X {axes.x.toFixed(2)}</span><span>Y {axes.y.toFixed(2)}</span><span>Z {axes.z.toFixed(2)}</span></div>}</div></div><div className="watch-strap strap-bottom" /><div className="wrist-hand" />
                </div>
                <div className="lens-crosshair" />
              </div>
              <div className="lens-caption"><span className="caption-rule" /> SIMULATED INERTIAL SENSOR <span className="caption-rule" /></div>
            </div>
            <div className="lens-footer flex items-center justify-between border-t border-white/[0.07] px-6 py-4 sm:px-8">
              <div className="flex items-center gap-2 text-xs text-[#8E8E98]"><Watch size={14} /> Wrist-mounted accelerometer <span className="ml-1 text-white/50">· ±2g range</span></div>
              <button className={`xray-button ${xray ? 'active' : ''}`} onClick={() => setXray((value) => !value)}><ScanLine size={14} /> X-Ray <span className="switch-track"><i /></span></button>
            </div>
          </article>

          <div className="right-stack">
            <article className="signal-panel surface rounded-[30px] border border-white/[0.09] p-5 sm:p-6">
              <div className="flex items-start justify-between">
                <div><div className="section-label">02 / RAW SIGNAL</div><h2 className="mt-1 text-sm font-medium">Acceleration magnitude</h2></div>
                <div className="signal-value"><span>{signal.toFixed(2)}</span><small>g</small></div>
              </div>
              <div className="telemetry-row mt-4 flex flex-wrap gap-2">
                {(['x', 'y', 'z'] as const).map((axis) => <div className="telemetry-chip" key={axis}><span>{axis.toUpperCase()}</span><b>{axes[axis].toFixed(2)}</b><small>g</small></div>)}
                <div className="telemetry-chip muted-chip"><AudioLines size={12} /><span>SMOOTHED</span></div>
              </div>
              <div className="wave-wrap mt-4" aria-label={`Live accelerometer signal ${signal.toFixed(2)} g`}>
                <div className="wave-grid" />
                <div className="threshold-line" style={{ top: `${Math.max(12, Math.min(83, 72 - threshold / 1.65 * 62))}%` }}><span>THRESHOLD <b>{threshold.toFixed(2)}g</b></span></div>
                <svg className="wave-svg" viewBox="0 0 100 72" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="wave-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FF4D2E" stopOpacity=".22"/><stop offset="1" stopColor="#FF4D2E" stopOpacity="0"/></linearGradient></defs><polygon points={`0,72 ${peakPoints} 100,72`} fill="url(#wave-fill)"/><polyline points={peakPoints} fill="none" stroke="#E5E3DF" strokeWidth=".65" vectorEffect="non-scaling-stroke" /></svg>
                <div className="wave-axis"><span>−1.0g</span><span>0</span><span>+1.0g</span></div>
              </div>
              <div className="signal-legend mt-3 flex flex-wrap items-center gap-x-4 gap-y-2"><span><i className="legend-dot accepted" />Accepted <b>{watchSteps}</b></span><span><i className="legend-dot rejected" />Below threshold</span><span className="ml-auto font-mono text-[10px] text-[#62626B]">T−{(tick % 60).toString().padStart(2, '0')}s</span></div>
              <label className="slider-line mt-4 block"><span className="flex justify-between"><span>DETECTION THRESHOLD</span><b>{threshold.toFixed(2)} <small>g</small></b></span><input aria-label="Detection threshold" type="range" min="0.2" max="1.5" step="0.01" value={threshold} onChange={(event) => { setThreshold(Number(event.target.value)); setPreset('Normal Walk') }} /></label>
            </article>

            <article className="scenario-panel surface rounded-[30px] border border-white/[0.09] p-5 sm:p-6">
              <div className="flex items-center justify-between"><div><div className="section-label">03 / MOTION PROFILE</div><h2 className="mt-1 text-sm font-medium">Choose a scenario</h2></div><span className="tiny-mono">TEST CONDITION <ChevronDown size={12} /></span></div>
              <div className="scenario-grid mt-4">{scenarios.map((item, index) => <button key={item.name} className={`scenario-option ${scenario === item.name ? 'active' : ''}`} onClick={() => { setScenario(item.name); setPreset('Normal Walk') }}><span className={`scenario-icon icon-${index}`}><i /></span><span className="scenario-copy"><b>{item.name}</b><small>{item.detail}</small></span>{scenario === item.name && <span className="scenario-check"><Check size={11} /></span>}</button>)}</div>
              <div className="control-row mt-5">
                <Control label="Intensity" value={intensity} min={0.2} max={1.6} step={0.01} display={`${intensity.toFixed(2)}×`} onChange={(v) => { setIntensity(v); setPreset('Normal Walk') }} />
                <Control label="Noise" value={noise} min={0} max={0.5} step={0.01} display={`${noise.toFixed(2)}g`} onChange={(v) => { setNoise(v); setPreset('Normal Walk') }} />
                <Control label="Interval" value={interval} min={280} max={1100} step={10} display={`${interval}ms`} onChange={(v) => { setInterval(v); setPreset('Normal Walk') }} />
              </div>
              <div className="algorithm-note mt-4"><Gauge size={14} /><span>{note}</span></div>
            </article>

          </div>
        </section>

        <footer className="mt-6 flex flex-wrap items-center justify-between gap-3 px-2 text-[10px] uppercase tracking-[0.13em] text-[#66666F]"><span>STEPWISE <span className="px-2 text-white/20">/</span> A sensor perception study</span><span className="flex items-center gap-2"><span className="footer-pulse" /> SYNTHETIC DATA · NOT A MEDICAL DEVICE</span><span className="flex items-center gap-1">SIGNAL ENGINE <ArrowUpRight size={11} /></span></footer>
      </div>
    </main>
  )
}

function Control({ label, value, min, max, step, display, onChange }: { label: string; value: number; min: number; max: number; step: number; display: string; onChange: (value: number) => void }) {
  return <label className="control-item"><span className="control-label">{label}</span><span className="control-value">{display}</span><input aria-label={label} type="range" min={min} max={max} step={step} value={value} onChange={(event) => onChange(Number(event.target.value))} /></label>
}
