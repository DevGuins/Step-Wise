'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, ArrowRight, ArrowUpRight, Check, Waves } from 'lucide-react'

function AxisDiagram() {
  return (
    <svg viewBox="0 0 560 330" role="img" aria-labelledby="axis-title axis-desc" className="deep-svg">
      <title id="axis-title">Watch accelerometer axes</title>
      <desc id="axis-desc">A wristwatch IMU measures acceleration along three perpendicular axes while gravity contributes a steady component.</desc>
      <defs><linearGradient id="wrist" x1="0" x2="1"><stop stopColor="#253247"/><stop offset="1" stopColor="#111b2b"/></linearGradient><filter id="glow"><feGaussianBlur stdDeviation="5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
      <g fill="none" stroke="#263347" strokeWidth="1"><circle cx="300" cy="170" r="126"/><circle cx="300" cy="170" r="90"/><path d="M45 170h510M300 24v292" strokeDasharray="3 7"/></g>
      <path d="M70 155c44-27 76-33 115-18l82 30c43 16 81 16 124 3l101-30v53l-101 31c-44 14-81 13-124-3l-82-30c-38-14-71-9-115 18z" fill="url(#wrist)" stroke="#42516a" strokeWidth="2"/>
      <g transform="rotate(-12 283 169)"><rect x="247" y="124" width="74" height="92" rx="17" fill="#0b101c" stroke="#10b981" strokeWidth="2"/><rect x="258" y="136" width="52" height="66" rx="11" fill="#101b29" stroke="#34445b"/><circle cx="284" cy="168" r="11" fill="#10b981" fillOpacity=".18" stroke="#10b981"/><circle cx="284" cy="168" r="3" fill="#d1fae5"/></g>
      <g strokeWidth="3" strokeLinecap="round" filter="url(#glow)"><path d="M284 168h118" stroke="#10b981"/><path d="M284 168v-92" stroke="#38bdf8"/><path d="M284 168l-69 62" stroke="#f59e0b"/></g>
      <g fontFamily="monospace" fontSize="13" fontWeight="600"><text x="410" y="172" fill="#10b981">X · FORWARD</text><text x="294" y="66" fill="#38bdf8">Y · VERTICAL</text><text x="151" y="247" fill="#f59e0b">Z · SIDE-TO-SIDE</text></g>
      <text x="24" y="304" fill="#8592a6" fontFamily="monospace" fontSize="10" letterSpacing="2">3-AXIS MEMS · APPROX. 50 SAMPLES / SECOND</text>
    </svg>
  )
}

function FilterDiagram() {
  return (
    <svg viewBox="0 0 560 330" role="img" aria-labelledby="filter-title filter-desc" className="deep-svg">
      <title id="filter-title">Raw acceleration smoothed by a low-pass filter</title>
      <desc id="filter-desc">A noisy amber acceleration waveform is transformed into a cleaner emerald walking-frequency signal.</desc>
      <g stroke="#283548" strokeWidth="1"><path d="M64 54v218h452M64 106h452M64 160h452M64 214h452" strokeDasharray="3 7"/></g>
      <path d="M65 175l11-17 8 33 13-51 9 29 10-48 10 78 11-28 9 9 12-65 10 43 11-15 10 62 12-76 11 41 10-20 12 68 10-61 11 13 11-46 10 65 10-29 13 24 10-56 10 32 12-12 10 50 12-66 10 30 12-15 12 54 10-41 11 17 12-59 10 42 12-10 10 40 12-35 12 17 11-42 12 28 12-9 10 37 12-44 11 22 13-12 11 35 12-31 10 15 11-27 12 22 12-10 12 20" fill="none" stroke="#f59e0b" strokeOpacity=".72" strokeWidth="1.7"/>
      <path d="M65 177c28-3 35-6 53-7s27 3 43 0 26-13 43-12 28 7 44 8 28-4 44-5 27 2 44 1 27-10 44-10 28 9 44 10 28-3 44-4 28 0 46 1" fill="none" stroke="#10b981" strokeWidth="3"/>
      <circle cx="248" cy="166" r="5" fill="#10b981"/><circle cx="380" cy="152" r="5" fill="#10b981"/>
      <text x="66" y="38" fill="#9aa7ba" fontFamily="monospace" fontSize="11" letterSpacing="2">RAW SIGNAL → FILTERED MAGNITUDE</text>
      <g fontFamily="monospace" fontSize="10"><path d="M74 297h20" stroke="#f59e0b" strokeWidth="2"/><text x="101" y="301" fill="#a7b1c0">SENSOR JITTER</text><path d="M246 297h20" stroke="#10b981" strokeWidth="3"/><text x="273" y="301" fill="#a7b1c0">LOW-PASS OUTPUT</text></g>
      <text x="404" y="38" fill="#38bdf8" fontFamily="monospace" fontSize="10">|a| − 1g</text>
    </svg>
  )
}

function ThresholdDiagram() {
  return (
    <svg viewBox="0 0 560 330" role="img" aria-labelledby="threshold-title threshold-desc" className="deep-svg">
      <title id="threshold-title">Peak detection against a threshold</title>
      <desc id="threshold-desc">Two peaks cross the threshold and are accepted; a smaller ripple below the line is ignored.</desc>
      <g stroke="#283548" strokeWidth="1"><path d="M56 48v224h464M56 100h464M56 154h464M56 208h464" strokeDasharray="3 7"/></g>
      <path d="M58 218c28 0 38-2 52-2 18-1 23-8 34-12 11-4 15 14 26 12 12-2 18-44 29-74 8-22 18-24 26 1 8 23 14 56 28 61 14 6 23-3 34-8 15-7 17 8 30 7 17-1 22-55 33-90 8-25 19-24 27 5 8 28 13 63 28 69 12 5 24-4 37-9 17-6 20 9 37 7 17-2 24-13 41-13" fill="none" stroke="#38bdf8" strokeWidth="3"/>
      <path d="M58 145h462" stroke="#f59e0b" strokeWidth="2" strokeDasharray="7 6"/>
      <circle cx="225" cy="143" r="6" fill="#10b981" stroke="#d1fae5" strokeWidth="2"/><circle cx="363" cy="142" r="6" fill="#10b981" stroke="#d1fae5" strokeWidth="2"/><circle cx="144" cy="204" r="5" fill="#637184"/>
      <text x="389" y="132" fill="#f59e0b" fontFamily="monospace" fontSize="11">THRESHOLD</text>
      <text x="189" y="102" fill="#10b981" fontFamily="monospace" fontSize="10">ACCEPTED PEAK</text><text x="94" y="247" fill="#7c8ba0" fontFamily="monospace" fontSize="10">IGNORED RIPPLE</text>
      <path d="M195 109l18 20M137 238l5-25" stroke="#8090a5" strokeWidth="1"/>
      <text x="58" y="35" fill="#9aa7ba" fontFamily="monospace" fontSize="11" letterSpacing="2">LOCAL MAXIMA · AMPLITUDE TEST</text>
    </svg>
  )
}

function RefractoryDiagram() {
  return (
    <svg viewBox="0 0 560 330" role="img" aria-labelledby="interval-title interval-desc" className="deep-svg">
      <title id="interval-title">Refractory period after a valid step</title>
      <desc id="interval-desc">After an accepted peak, the detection gate briefly locks out a second peak, then reopens for the next step.</desc>
      <path d="M65 216h450M65 80v174" stroke="#2b384b" strokeWidth="1"/><path d="M65 216h450" stroke="#40506a" strokeDasharray="3 7"/>
      <path d="M83 216c28 0 31-2 45-4 17-3 25-69 37-99 9-22 19-20 27 5 10 31 16 88 38 94 16 4 24 4 42 4 13 0 17-31 26-52 8-19 17-17 24 4 7 22 12 44 29 48 20 5 35 0 51-3 16-3 23-70 36-97 9-19 18-16 25 8 8 28 13 75 31 87 13 8 29 3 43 2" fill="none" stroke="#38bdf8" strokeWidth="3"/>
      <circle cx="165" cy="112" r="6" fill="#10b981" stroke="#d1fae5" strokeWidth="2"/><circle cx="226" cy="212" r="5" fill="#f59e0b" stroke="#fef3c7" strokeWidth="2"/><circle cx="436" cy="119" r="6" fill="#10b981" stroke="#d1fae5" strokeWidth="2"/>
      <path d="M165 77v-20h129v20" fill="none" stroke="#f59e0b" strokeWidth="2"/><path d="M165 57h129" stroke="#f59e0b" strokeWidth="2" strokeDasharray="5 5"/>
      <rect x="165" y="274" width="129" height="22" rx="11" fill="#f59e0b" fillOpacity=".12" stroke="#f59e0b" strokeOpacity=".45"/><text x="179" y="289" fill="#fbbf24" fontFamily="monospace" fontSize="9">REFRACTORY · 250–400 ms</text>
      <text x="125" y="42" fill="#10b981" fontFamily="monospace" fontSize="10">VALID STEP</text><text x="207" y="246" fill="#f59e0b" fontFamily="monospace" fontSize="9">LOCKED OUT</text><text x="404" y="96" fill="#10b981" fontFamily="monospace" fontSize="10">GATE OPEN</text>
      <text x="66" y="319" fill="#9aa7ba" fontFamily="monospace" fontSize="10" letterSpacing="2">ONE IMPACT, ONE COUNT</text>
    </svg>
  )
}

function GaitCompareDiagram() {
  return (
    <svg viewBox="0 0 700 300" role="img" aria-labelledby="compare-title compare-desc" className="deep-svg">
      <title id="compare-title">Walking gait compared with seated hand motion</title>
      <desc id="compare-desc">Walking produces repeated aligned peaks across vertical acceleration and swing; isolated seated gestures produce irregular peaks without a repeating gait pattern.</desc>
      <g fontFamily="monospace" fontSize="10" letterSpacing="1"><text x="30" y="35" fill="#10b981">WALKING GAIT · RHYTHMIC & COORDINATED</text><text x="370" y="35" fill="#f59e0b">SEATED HAND MOTION · ISOLATED</text></g>
      <path d="M350 24v250" stroke="#283548" strokeDasharray="4 7"/>
      <g stroke="#29364a" strokeWidth="1"><path d="M34 110h300M34 202h300M370 110h300M370 202h300" strokeDasharray="3 7"/></g>
      <text x="35" y="75" fill="#91a0b5" fontFamily="monospace" fontSize="9">Y · VERTICAL</text><text x="35" y="169" fill="#91a0b5" fontFamily="monospace" fontSize="9">X/Z · SWING</text>
      <path d="M35 111c20 0 23-4 30-8 8-4 10-40 20-40s14 42 22 47 16 1 23-7 10-42 20-42 14 42 23 48 15 0 23-7 10-43 20-43 14 41 23 47 15 1 23-7 10-42 20-42 14 41 22 47 16 1 30-2" fill="none" stroke="#10b981" strokeWidth="2.5"/>
      <path d="M35 204c22-2 36-6 50-11s25-10 39-14 24-4 35-3 21 5 32 11 23 12 36 15 25 2 38-3 22-10 35-13 24-1 36 3" fill="none" stroke="#38bdf8" strokeWidth="2.5"/>
      <path d="M370 111c32 0 42-4 58-7 11-2 17-38 26-38 11 0 14 42 23 46 8 3 19-3 30-4s16-1 26 1 17 3 27 0 20-3 29-2 19 4 28 4 20-4 34 0" fill="none" stroke="#f59e0b" strokeWidth="2.5"/>
      <path d="M370 204c34-1 45-3 58-5 16-3 24-15 31-16 9-1 13 15 23 18 11 4 24 1 37 0 13-2 22-1 34 1 15 2 24 1 38-2 14-2 29-1 46 0 13 1 22-1 34-2" fill="none" stroke="#fca5a5" strokeWidth="2.5"/>
      <g fontFamily="monospace" fontSize="9"><text x="44" y="250" fill="#10b981">REPEATED HEEL-STRIKE IMPULSES</text><text x="385" y="250" fill="#fbbf24">1–2 SPIKES · NO STEADY CADENCE</text><text x="44" y="272" fill="#74839a">aligned phase pattern</text><text x="385" y="272" fill="#74839a">no consistent vertical impact</text></g>
    </svg>
  )
}

const pipeline = [
  { id: '01', title: '3-Axis MEMS Sensing', subtitle: 'X · Y · Z', color: 'mint', text: 'A wrist-worn inertial sensor samples acceleration along three perpendicular axes. At roughly 50 Hz, it sees both movement and Earth’s gravity—not a foot touching the ground.' },
  { id: '02', title: 'Composite Magnitude & Filtering', subtitle: 'ORIENTATION-ROBUST SIGNAL', color: 'sky', text: 'The vector magnitude √(x² + y² + z²), minus about 1g, reduces sensitivity to wrist orientation. A low-pass filter softens rapid jitter while preserving the slower rhythm of walking.' },
  { id: '03', title: 'Peak Detection & Threshold', subtitle: 'AMPLITUDE VALIDATION', color: 'amber', text: 'The detector finds local maxima and tests each against a fixed or adaptive threshold. Raise it and gentle steps may disappear; lower it and small gestures may pass.' },
  { id: '04', title: 'Refractory Period & Validation', subtitle: 'TIMING GATE', color: 'mint', text: 'After a candidate step, a short lockout—often around 250–400 ms—prevents one impact from counting twice. Rhythm checks can reject isolated peaks; exact rules vary by device.' },
]

const conditions = [
  ['01', 'Sufficient peak amplitude', 'A candidate acceleration peak must cross the detector’s threshold. The threshold may adapt to recent motion and sensor noise.'],
  ['02', 'Valid timing', 'The peak must arrive after the refractory gate reopens. Walking cadence commonly spans roughly 90–140 steps per minute, with person-to-person variation.'],
  ['03', 'Rhythmic continuity', 'Some algorithms buffer several consecutive, regularly spaced peaks before confirming a count; published designs use different buffer lengths and rules.'],
  ['04', 'A plausible gait signature', 'Additional logic can compare axis patterns and timing. A periodic vertical component aligned with arm swing is more gait-like than a lone wrist flick.'],
]

export default function StepwiseDeepDive() {
  const [activePipelineStep, setActivePipelineStep] = useState<string | null>(null)
  const visiblePipeline = activePipelineStep ? pipeline.filter((step) => step.id === activePipelineStep) : pipeline

  return (
    <main className="deep-page">
      <div className="deep-shell">
        <header className="deep-header">
          <Link href="/" className="deep-back"><ArrowLeft size={15} aria-hidden="true" /> Back to Simulator</Link>
          <Link href="/" className="deep-wordmark" aria-label="STEPWISE simulator">STEP<span>—</span>WISE <span className="deep-wordmark-note">MOTION LAB / FIELD NOTES</span></Link>
        </header>

        <section className="deep-hero">
          <div className="deep-kicker"><span className="deep-live-dot" /> SENSOR LOGIC / TECHNICAL BRIEF <span>04 MIN READ</span></div>
          <h1>From wrist motion<br />to a <em>counted step.</em></h1>
          <p>A watch does not see footsteps. It measures acceleration, searches for a repeatable pattern, then decides whether a peak is plausible enough to count.</p>
          <div className="deep-hero-stats"><span><b>3</b> sensing axes</span><span><b>~50 Hz</b> example sample rate</span><span><b>4</b> detection stages</span></div>
        </section>

        <section className="deep-section-heading" id="pipeline">
          <span className="deep-section-index">01 / SIGNAL PATH</span><h2>The four-step pipeline</h2><p>How raw wrist motion becomes a step candidate.</p>
        </section>
        <div className="deep-pipeline-filter" role="group" aria-label="Filter pipeline by step">
          <button type="button" aria-pressed={activePipelineStep === null} onClick={() => setActivePipelineStep(null)}>All stages</button>
          {pipeline.map((step) => <button type="button" key={step.id} aria-pressed={activePipelineStep === step.id} onClick={() => setActivePipelineStep(step.id)}>{step.id} · {step.title}</button>)}
        </div>

        <div className="deep-pipeline" aria-live="polite">
          {visiblePipeline.map((step, index) => (
            <article id={`pipeline-${step.id}`} className={`deep-pipeline-row ${index % 2 ? 'reverse' : ''}`} key={step.id}>
              <div className="deep-copy">
                <div className={`deep-step-label ${step.color}`}><span>{step.id}</span><i />{step.subtitle}</div>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
                {step.id === '02' && <div className="deep-equation">a<sub>mag</sub> = √(x² + y² + z²) − 1g</div>}
              </div>
              <div className="deep-visual">{step.id === '01' ? <AxisDiagram /> : step.id === '02' ? <FilterDiagram /> : step.id === '03' ? <ThresholdDiagram /> : <RefractoryDiagram />}</div>
            </article>
          ))}
        </div>

        <section className="deep-section-heading" id="conditions">
          <span className="deep-section-index">02 / VALIDATION CHECK</span><h2>When does movement count?</h2><p>All four signals support a plausible step—but implementations differ.</p>
        </section>
        <section className="deep-conditions">
          <div className="deep-condition-intro"><div className="deep-condition-icon"><Check size={18}/></div><div><h3>Four conditions, one decision</h3><p>A simple peak counter may use only amplitude and timing. More advanced systems can add cadence, axis relationships, and context.</p></div></div>
          <div className="deep-condition-grid">{conditions.map(([number, title, text]) => <article className="deep-condition" key={number}><span>{number}</span><div><h4>{title}</h4><p>{text}</p></div></article>)}</div>
        </section>

        <section className="deep-section-heading" id="false-positives">
          <span className="deep-section-index">03 / FALSE-POSITIVE REJECTION</span><h2>Walking gait vs. seated hand motion</h2><p>Why a wrist gesture can look step-like—and what helps a watch tell the difference.</p>
        </section>
        <section className="deep-compare-panel"><GaitCompareDiagram /></section>
        <div className="deep-rejection-grid">
          <article><span>01 / CADENCE</span><h3>Gestures are usually isolated</h3><p>Typing, reaching, or checking a phone often creates one or two irregular spikes—not a sustained sequence of evenly spaced peaks.</p></article>
          <article><span>02 / IMPACT</span><h3>No repeating heel-strike cue</h3><p>Walking can produce periodic vertical acceleration linked to foot-ground impact. Seated hand motion usually lacks that repeated, synchronized component.</p></article>
          <article><span>03 / SIGNAL BAND</span><h3>Noise and micro-motion differ</h3><p>Filtering and amplitude rules can suppress small tremors or rapid jitter. Walking frequency is not a universal fixed band; cadence varies with the person and activity.</p></article>
          <article><span>04 / CONTEXT</span><h3>More sensors add evidence</h3><p>Some devices combine accelerometer patterns with gyroscope rotation and broader activity context. GPS, barometer, and heart rate may support activity inference, but are not guaranteed step-by-step gates.</p></article>
        </div>

        <section className="deep-takeaway">
          <div className="deep-takeaway-mark"><Waves size={19}/></div>
          <div className="deep-takeaway-copy"><span>04 / BACK TO THE EXPERIMENT</span><h2>Why can our simulator still fool it?</h2><p>STEPWISE models a deliberately simple threshold-and-interval detector. It relies on acceleration peaks alone, so a larger <b>Arm Swing</b>, a lower <b>Threshold</b>, or added <b>Noise</b> can expose the weakness that richer sensor fusion and activity classifiers are designed to reduce.</p><p className="deep-caveat">This is a teaching model, not a replica of any specific smartwatch algorithm. Real devices differ by manufacturer, firmware, and activity context.</p></div>
          <Link href="/" className="deep-test-link">Test this in the live simulator <ArrowRight size={16} aria-hidden="true" /></Link>
        </section>

        <footer className="deep-references">
          <div><span className="deep-section-index">FURTHER READING</span><h2>Scientific &amp; Engineering References</h2><p>Background on inertial sensing, step detection, and wearable gait analysis. Algorithm details and performance depend on implementation.</p></div>
          <ol>
            <li><a href="https://www.analog.com/media/en/technical-documentation/application-notes/AN-1025.pdf" target="_blank" rel="noreferrer">Analog Devices, <i>AN-1025: Pedometer Design Using the ADXL345</i>.</a> Example 3-axis algorithm using filtering, adaptive peak logic, and rhythmic validation.</li>
            <li><a href="https://doi.org/10.3390/s140203362" target="_blank" rel="noreferrer">Muro-de-la-Herran, A., García-Zapirain, B., &amp; Méndez-Zorrilla, A. (2014). “Gait analysis methods: An overview of wearable and non-wearable systems.” <i>Sensors, 14</i>(2), 3362–3394.</a></li>
            <li><a href="https://doi.org/10.3390/s100807779" target="_blank" rel="noreferrer">Yang, C.-C., &amp; Hsu, Y.-L. (2010). “A Review of Accelerometry-Based Wearable Motion Detectors for Physical Activity Monitoring.” <i>Sensors, 10</i>(8), 7772–7788.</a></li>
          </ol>
          <div className="deep-footer-line"><Link href="/" className="deep-back"><ArrowLeft size={14} aria-hidden="true" /> Back to Simulator</Link><span>STEPWISE / SIGNAL PERCEPTION STUDY</span><a href="#pipeline" aria-label="Back to top"><ArrowUpRight size={15} /></a></div>
        </footer>
      </div>
    </main>
  )
}
