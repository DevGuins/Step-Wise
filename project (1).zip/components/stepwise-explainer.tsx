'use client'

type GuideStep = '01' | '02' | '03' | '04'

const steps: { number: GuideStep; title: string; description: string }[] = [
  {
    number: '01',
    title: 'Wrist & accelerometer',
    description: 'Measures wrist acceleration plus gravity on X, Y, Z—not footfalls. Watch the wrist move; arm waves or a bumpy ride can imitate walking.',
  },
  {
    number: '02',
    title: 'Signal & noise filter',
    description: 'Combines X, Y, Z into one motion signal, then smooths high-frequency jitter. Tune motion and noise to see the waveform sharpen or settle.',
  },
  {
    number: '03',
    title: 'Peak & threshold check',
    description: 'Finds signal peaks and tests them against the threshold line. Raise it to miss softer real steps; lower it to invite false triggers.',
  },
  {
    number: '04',
    title: 'Interval & validation',
    description: 'Counts qualifying peaks only after the minimum detection interval. Tune the cooldown to prevent double counts—or let convincing non-walking motion through.',
  },
]

export function StepwiseExplainer({
  selectedStep,
  onSelectStep,
}: {
  selectedStep: GuideStep | null
  onSelectStep: (step: GuideStep | null) => void
}) {
  return (
    <section className="walkthrough" aria-labelledby="walkthrough-title">
      <div className="walkthrough-heading">
        <div>
          <p className="section-label">THE DETECTION PATH / 01—04</p>
          <h2 id="walkthrough-title">How Each Step Works</h2>
        </div>
        <span>UNDER 3-MIN WALKTHROUGH</span>
      </div>
      <div className="walkthrough-grid">
        {steps.map((step) => (
          <button
            key={step.number}
            type="button"
            aria-pressed={selectedStep === step.number}
            onClick={() => onSelectStep(selectedStep === step.number ? null : step.number)}
            className={`walkthrough-card ${selectedStep === step.number ? 'selected' : ''}`}
          >
            <span className="walkthrough-card-top">
              <span className="walkthrough-number">{step.number}</span>
              <span className="walkthrough-title">{step.title}</span>
              <span className="walkthrough-indicator" aria-hidden="true" />
            </span>
            <span className="walkthrough-copy">{step.description}</span>
          </button>
        ))}
      </div>
    </section>
  )
}

export type { GuideStep }
