import StepwiseLab from '@/components/stepwise-lab'

export default function Page() {
  return <StepwiseLab />
}
