import type { Metadata } from 'next'
import StepwiseDeepDive from '@/components/stepwise-deep-dive'

export const metadata: Metadata = {
  title: 'How It Works — STEPWISE Motion Lab',
  description: 'Explore how wearable accelerometers turn wrist motion into step counts, and why simple detectors can be fooled.',
}

export default function HowItWorksPage() {
  return <StepwiseDeepDive />
}
